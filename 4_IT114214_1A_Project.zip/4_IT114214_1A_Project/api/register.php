<?php
require_once 'config.php';

$data = json_decode(file_get_contents('php://input'), true);
$username = trim($data['username'] ?? '');
$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';

if (empty($username) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => '請填寫所有欄位']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => '請輸入有效的電郵地址']);
    exit;
}
if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => '密碼至少 6 個字元']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
$stmt->execute([$username, $email]);
if ($stmt->rowCount() > 0) {
    echo json_encode(['success' => false, 'message' => '用戶名或電郵已經被註冊']);
    exit;
}

$hashed = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
if ($stmt->execute([$username, $email, $hashed])) {
    echo json_encode(['success' => true, 'message' => '註冊成功']);
} else {
    echo json_encode(['success' => false, 'message' => '註冊失敗，請稍後再試']);
}
?>