<?php
require_once 'config.php';

// 獲取產品
$category = $_GET['category'] ?? 'all';
$keyword = $_GET['search'] ?? '';

$sql = "SELECT * FROM products WHERE 1=1";
$params = [];

if (!empty($keyword)) {
    $sql .= " AND (name LIKE ? OR name_en LIKE ? OR name_cn LIKE ?)";
    $like = "%$keyword%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if ($category !== 'all') {
    $sql .= " AND category = ?";
    $params[] = $category;
}

$sql .= " ORDER BY id LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

// 獲取分類（用於導航高亮）
$categories = ['biscuit', 'chip', 'chocolate', 'other', 'coffee_tea', 'energy', 'juice', 'soda'];
?>
<!DOCTYPE html>
<html lang="zh-HK">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>零食站 · 零食飲品專門店</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-top">
                <div class="logo">
                    <span class="logo-icon">🧁</span>
                    <span class="logo-text">零食站</span>
                    <span class="logo-tag">Snack Station</span>
                </div>
                <div class="header-actions">
                    <!-- 用戶狀態 -->
                    <div class="user-status">
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <span>👋 歡迎，<strong><?= htmlspecialchars($_SESSION['username']) ?></strong></span>
                            <a href="logout.php" class="btn-logout">登出</a>
                        <?php else: ?>
                            <a href="login.php" class="btn-login">登入</a>
                            <a href="register.php" class="btn-register">註冊</a>
                        <?php endif; ?>
                    </div>
                    <div class="lang-switch">
                        <button class="lang-btn active" data-lang="zh-HK">繁</button>
                        <button class="lang-btn" data-lang="zh-CN">简</button>
                        <button class="lang-btn" data-lang="en">EN</button>
                    </div>
                    <div class="cart-icon-wrapper" id="cartToggle">
                        <span>🛒</span>
                        <span class="cart-count" id="cartCount">0</span>
                    </div>
                </div>
            </div>
            <!-- 搜尋 -->
            <div class="search-row">
                <form class="search-box" method="GET" action="index.php">
                    <span class="search-icon">🔍</span>
                    <input type="text" name="search" placeholder="搜尋零食或飲品..." value="<?= htmlspecialchars($keyword) ?>" />
                    <button type="submit">搜尋</button>
                </form>
            </div>
        </div>
    </header>

    <!-- 導航 -->
    <nav class="main-nav">
        <div class="container">
            <ul class="nav-list">
                <li><a href="index.php" class="nav-link <?= $category == 'all' ? 'active' : '' ?>">🏠 首頁</a></li>
                <li class="dropdown">
                    <a href="#" class="nav-link">🍿 零食 ▾</a>
                    <ul class="dropdown-menu">
                        <li><a href="index.php?category=biscuit" class="nav-link <?= $category == 'biscuit' ? 'active' : '' ?>">🍪 餅乾</a></li>
                        <li><a href="index.php?category=chip" class="nav-link <?= $category == 'chip' ? 'active' : '' ?>">🥔 薯片</a></li>
                        <li><a href="index.php?category=chocolate" class="nav-link <?= $category == 'chocolate' ? 'active' : '' ?>">🍫 朱古力</a></li>
                        <li><a href="index.php?category=other" class="nav-link <?= $category == 'other' ? 'active' : '' ?>">🍢 其他</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="nav-link">🥤 飲品 ▾</a>
                    <ul class="dropdown-menu">
                        <li><a href="index.php?category=coffee_tea" class="nav-link <?= $category == 'coffee_tea' ? 'active' : '' ?>">☕ 咖啡·茶</a></li>
                        <li><a href="index.php?category=energy" class="nav-link <?= $category == 'energy' ? 'active' : '' ?>">⚡ 運動·能量</a></li>
                        <li><a href="index.php?category=juice" class="nav-link <?= $category == 'juice' ? 'active' : '' ?>">🍊 果汁</a></li>
                        <li><a href="index.php?category=soda" class="nav-link <?= $category == 'soda' ? 'active' : '' ?>">🥤 碳酸飲料</a></li>
                    </ul>
                </li>
                <li><a href="#" class="nav-link">💬 關於我哋</a></li>
            </ul>
        </div>
    </nav>

    <!-- Banner -->
    <section class="banner-section">
        <div class="container">
            <div class="banner-card">
                <div class="banner-content">
                    <h2>🍭 夏日狂歡 · 全場 8 折</h2>
                    <p>買滿 $200 即享折扣優惠，仲有免費送貨！</p>
                    <a href="#" class="btn-banner">🔥 即刻搶購</a>
                </div>
                <div class="banner-emoji">🧁</div>
            </div>
        </div>
    </section>

    <!-- 商品區 -->
    <section class="products-section">
        <div class="container">
            <div class="section-header">
                <h3>🔥 人氣推介</h3>
                <span class="product-count">共 <?= count($products) ?> 件商品</span>
            </div>
            <div class="grid" id="productGrid">
                <?php if (count($products) === 0): ?>
                    <div class="empty-state">😅 沒有找到相關產品，試吓其他關鍵字啦！</div>
                <?php else: ?>
                    <?php foreach ($products as $p): ?>
                        <?php $isHot = $p['price'] >= 20 && $p['category'] !== 'drink'; ?>
                        <div class="card" data-id="<?= $p['id'] ?>" data-name="<?= htmlspecialchars($p['name']) ?>" data-price="<?= $p['price'] ?>">
                            <?php if ($isHot): ?><span class="badge-hot">🔥 熱賣</span><?php endif; ?>
                            <div class="card-image" style="background:<?= getColor($p['category']) ?>;">
                                <span class="card-emoji"><?= getEmoji($p['category']) ?></span>
                            </div>
                            <h4><?= htmlspecialchars($p['name']) ?></h4>
                            <p class="product-weight"><?= htmlspecialchars($p['weight']) ?></p>
                            <p class="product-price">$<?= number_format($p['price'], 2) ?></p>
                            <button class="add-to-cart" data-id="<?= $p['id'] ?>" data-name="<?= htmlspecialchars($p['name']) ?>" data-price="<?= $p['price'] ?>">🛒 加入購物車</button>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 購物車側欄 -->
    <div id="cartSidebar" class="cart-sidebar">
        <div class="cart-header">
            <h2>🛒 購物車</h2>
            <button id="closeCart">✕</button>
        </div>
        <div id="cartItems" class="cart-items">
            <p class="empty-cart">🛒 購物車目前空空如也</p>
        </div>
        <div class="cart-footer">
            <div class="cart-total">
                <span>總計</span>
                <span id="cartTotal">$0</span>
            </div>
            <div class="cart-buttons">
                <button id="clearCart" class="btn-clear">🗑️ 清空</button>
                <button id="checkoutBtn" class="btn-checkout">💳 結帳</button>
            </div>
        </div>
    </div>
    <div id="cartOverlay" class="cart-overlay"></div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <p>© 2026 零食站 · 專營零食飲品</p>
                <p class="footer-note">🍭 用心為你揀選最好嘅零食</p>
            </div>
        </div>
    </footer>

    <?php
    // Helper functions
    function getColor($category) {
        $colors = [
            'biscuit' => '#f9d56e',
            'chip' => '#f5b895',
            'chocolate' => '#c9b1a0',
            'other' => '#9fd9b2',
            'coffee_tea' => '#7ec8e3',
            'energy' => '#f7a072',
            'juice' => '#f7c35c',
            'soda' => '#d4a0a0'
        ];
        return $colors[$category] ?? '#ddd';
    }

    function getEmoji($category) {
        $emojis = [
            'biscuit' => '🍪',
            'chip' => '🥔',
            'chocolate' => '🍫',
            'other' => '🍢',
            'coffee_tea' => '☕',
            'energy' => '⚡',
            'juice' => '🍊',
            'soda' => '🥤'
        ];
        return $emojis[$category] ?? '🍭';
    }
    ?>

    <style>
        .user-status { display: flex; align-items: center; gap: 10px; font-size: 14px; }
        .btn-login, .btn-register, .btn-logout { padding: 6px 16px; border-radius: 30px; text-decoration: none; font-weight: 600; font-size: 13px; transition: 0.2s; }
        .btn-login { color: #d97747; background: #f5ede7; }
        .btn-login:hover { background: #e8dbd2; }
        .btn-register { color: #fff; background: #d97747; }
        .btn-register:hover { background: #b85e2e; }
        .btn-logout { color: #d44c4c; background: #fde8e8; }
        .btn-logout:hover { background: #f5d0d0; }
    </style>

    <script>
        // ===== 購物車功能（JavaScript） =====
        let cart = [];

        // 更新購物車 UI
        function updateCartUI() {
            const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
            document.getElementById('cartCount').textContent = totalItems;
            renderCartItems();

            const totalPrice = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
            document.getElementById('cartTotal').textContent = `$${totalPrice}`;
        }

        function renderCartItems() {
            const container = document.getElementById('cartItems');
            if (cart.length === 0) {
                container.innerHTML = `<p class="empty-cart">🛒 購物車目前空空如也</p>`;
                return;
            }

            let html = '';
            cart.forEach((item, index) => {
                html += `
                    <div class="cart-item">
                        <span class="cart-item-name">${item.name}</span>
                        <div class="cart-item-controls">
                            <button class="qty-btn" data-index="${index}" data-action="decrease">−</button>
                            <span class="cart-item-qty">${item.qty}</span>
                            <button class="qty-btn" data-index="${index}" data-action="increase">+</button>
                            <button class="cart-item-remove" data-index="${index}">✕</button>
                        </div>
                        <span class="cart-item-price">$${item.price * item.qty}</span>
                    </div>
                `;
            });
            container.innerHTML = html;

            document.querySelectorAll('.qty-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const index = parseInt(this.dataset.index);
                    const action = this.dataset.action;
                    if (action === 'increase') {
                        cart[index].qty += 1;
                    } else {
                        cart[index].qty -= 1;
                        if (cart[index].qty <= 0) cart.splice(index, 1);
                    }
                    updateCartUI();
                });
            });

            document.querySelectorAll('.cart-item-remove').forEach(btn => {
                btn.addEventListener('click', function() {
                    const index = parseInt(this.dataset.index);
                    cart.splice(index, 1);
                    updateCartUI();
                });
            });
        }

        // 加入購物車
        document.querySelectorAll('.add-to-cart').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = parseInt(this.dataset.id);
                const name = this.dataset.name;
                const price = parseInt(this.dataset.price);

                const existing = cart.find(item => item.id === id);
                if (existing) {
                    existing.qty += 1;
                } else {
                    cart.push({ id, name, price, qty: 1 });
                }

                updateCartUI();
                showToast(`✅ ${name} 已加入購物車`);
            });
        });

        // 側欄開關
        document.getElementById('cartToggle').addEventListener('click', () => {
            document.getElementById('cartSidebar').classList.add('open');
            document.getElementById('cartOverlay').classList.add('show');
        });

        document.getElementById('closeCart').addEventListener('click', () => {
            document.getElementById('cartSidebar').classList.remove('open');
            document.getElementById('cartOverlay').classList.remove('show');
        });

        document.getElementById('cartOverlay').addEventListener('click', () => {
            document.getElementById('cartSidebar').classList.remove('open');
            document.getElementById('cartOverlay').classList.remove('show');
        });

        // 清空購物車
        document.getElementById('clearCart').addEventListener('click', () => {
            if (cart.length === 0) return;
            if (confirm('確定要清空購物車嗎？')) {
                cart = [];
                updateCartUI();
            }
        });

        // 結帳
        document.getElementById('checkoutBtn').addEventListener('click', () => {
            if (cart.length === 0) {
                alert('購物車係空㗎，揀啲嘢先啦！');
                return;
            }
            alert('多謝幫襯！呢度之後會連接付款系統 💳');
        });

        // Toast
        function showToast(text) {
            const el = document.createElement('div');
            el.className = 'toast-msg';
            el.textContent = text;
            document.body.appendChild(el);
            setTimeout(() => el.remove(), 1800);
        }

        // 語言切換（簡化版）
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                // 呢度可以加真正嘅語言切換邏輯
            });
        });

        // 初始化
        updateCartUI();
    </script>
</body>
</html>