<?php
require_once 'config.php';

$category = $_GET['category'] ?? 'all';
$keyword = $_GET['search'] ?? '';

$sql = "SELECT * FROM products WHERE 1=1";
$params = [];

if (!empty($keyword)) {
    $sql .= " AND (name LIKE ? OR name_en LIKE ? OR name_cn LIKE ?)";
    $like = "%$keyword%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if ($category !== 'all') {
    $sql .= " AND category = ?";
    $params[] = $category;
}

$sql .= " ORDER BY id LIMIT 200";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

echo json_encode($products);
?>